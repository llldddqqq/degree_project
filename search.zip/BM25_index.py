import csv
import porter
import json
csv_file = csv.reader(open('PPR-ALL.csv', encoding='gbk'))
house_info = {}
house_index_info = {}
stopwords = []
punc = [',', '/', '.']
stemmer = porter.PorterStemmer()
with open("stopwords.txt", 'r') as f:
    for line in f:
        data = f.readline()
        stopwords.append(data.strip('\n'))
### store all info in dic
for line in csv_file:
    line2 = line
    temp = {'sale_date': line2[0], 'Post_code': line2[2], 'County': line2[3], 'price': line2[4],
            'not_full_price': line2[5],
            'vat': line2[6], 'property_info': line2[7], 'size': line2[8]}
    address = line2[1]
    house_info[address] = temp

##index the info
all_doclen = 0
N = len(house_info)
indoclen={}
for address in house_info:
    for info in house_info[address]:
        address_dic = {}
        terms = (house_info[address][info]+" "+str(address)).replace("\\pP|\\pS|\n", "").split(' ')
        #print(terms)
        for term in terms:
            if term not in stopwords:
                term = stemmer.stem(str(term))
                term = term.lower()
            if len(term) > 1:
                if term[0] == '/':
                    term = term[1:]
            if term == '':
                continue
            term=term.replace(',','')
            #print(term)
            if term not in address_dic:
                address_dic[term] = 1
            else:
                #print(terms,term,address_dic[term])
                address_dic[term] += 1
            #print(term,address_dic[term])
        indoclen[address] = len(address_dic)
        all_doclen = all_doclen + len(address_dic)
        house_index_info[address] = address_dic
#print(all_doclen,indoclen)
BM25 = {
               'k': 1,
               'b': 0.75,
               'avg_doclen': all_doclen / N,
               'N': N,
               'indoclen': indoclen,
               'house_index_info': house_index_info,
               'house_info':house_info
           }
desktop_path = ""  # 新创建的txt文件的存放路径
full_path = desktop_path + 'index' + '.txt'  # 也可以创建一个.doc的word文档
file = open(full_path, 'w')
js1 = json.dumps(BM25)
file.write(js1)
file.close()
